package View;

import model.Book;
import model.Member;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class MemberVC extends JInternalFrame implements ActionListener{
    private JLabel insert, id_insert;
    private JPanel p_insert, p_id, p_buttons;
    private JPasswordField id;
    private JButton accept, back;
    private MDI frame;
    private Font f1 = new Font("Arial Rounded MT Bold", Font.BOLD, 15);
    private Book book = new Book();
    private Member member = new Member();
    
    public MemberVC(String title, boolean resizable, boolean closable, boolean maximizable, boolean iconificable, MDI frame){
        super(title, resizable, closable, maximizable, iconificable);
        this.frame = frame;
        this.init();
    }
    
    public void init(){
        this.setLayout(new GridLayout(3,1));
        p_insert = new JPanel();
        p_id = new JPanel();
        p_buttons = new JPanel();
        p_id.setLayout(new FlowLayout());
        p_buttons.setLayout(new FlowLayout());
        
        insert = new JLabel("Insert Member ID");
        insert.setHorizontalAlignment(JLabel.CENTER);
        insert.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 20));
        p_insert.add(insert);
        p_insert.setBackground(new Color(69,68,68));
        insert.setForeground(Color.WHITE);

        id_insert = new JLabel("Member ID: ");
        id = new JPasswordField(20);
        p_id.add(id_insert); p_id.add(id);
        id_insert.setFont(f1);
        id.setFont(f1);
        p_id.setBackground(new Color(69,68,68));
        id_insert.setForeground(Color.WHITE);

        
        accept = new JButton("Next");
        back = new JButton("Back");
        p_buttons.add(back); p_buttons.add(accept);
        back.setFont(f1);
        accept.setFont(f1);

        accept.setBackground(new Color(250,0,100));
        accept.setForeground(Color.WHITE);

        back.setBackground(new Color(250,0,100));
        back.setForeground(Color.WHITE);

        p_buttons.setBackground(new Color(69,68,68));
        
        accept.addActionListener(this);
        back.addActionListener(this);
        
        ((javax.swing.plaf.basic.BasicInternalFrameUI)this.getUI()).setNorthPane(null);
        
        this.add(p_insert);
        this.add(p_id);
        this.add(p_buttons);
        this.setSize(400,350);
        this.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent ae){
        int index = 0;
        int check = 0;
        double totalprice = 0.00; //ราคาเช่า (Day x Price)
        for(int i = 0; i < Controller.Rent_Controller.bookList.size(); i++){
            totalprice += Controller.Rent_Controller.bookList.get(i).getPrice() * Controller.Rent_Controller.bookList.get(i).getDay();

        }

        if(ae.getSource().equals(accept)){
            while(index < member.getMemberList().size()){
                if(member.getMemberList().get(index).getId().equals(id.getText())==false){
                    index++;
                    check = 0;
                }
                else{
                    check = 1;
                    break;
                }
            }
            if(check == 0){
                JOptionPane.showMessageDialog(frame, "Invalid Member ID"); //ราคาตาม Collection หนังสือ
                id.setText("");
            }
            else{


                JOptionPane.showMessageDialog(frame, Controller.Rent_Controller.bookList.size()+ (" Book(s)\nTotal Price: " +(new DecimalFormat("##.##").format((totalprice * (0.95))))));
                this.frame.getMemberVC().setVisible(false);
                this.frame.getMemberVC().hide();
                this.frame.getDesktopPane().remove(this.frame.getMemberVC());
                this.frame.getDesktopPane().add(this.frame.getMainPage());
                this.frame.getMainPage().setVisible(true);
                this.frame.getMainPage().show();
                Controller.Rent_Controller.bookList.clear();
                id.setText("");
            }

        }
        if(ae.getSource().equals(back)){
            this.frame.getMemberVC().setVisible(false);
            this.frame.getMemberVC().hide();
            this.frame.getDesktopPane().remove(this.frame.getMemberVC());
            this.frame.getDesktopPane().add(this.frame.getPricePreview());
            this.frame.getPricePreview().setVisible(true);
            this.frame.getPricePreview().show();
        }
    }
}
